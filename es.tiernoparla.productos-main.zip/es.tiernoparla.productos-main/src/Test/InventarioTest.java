package Test;

import org.junit.jupiter.api.Test;

import tienda.Inventario;
import tienda.Producto;

import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class InventarioTest {

    @Test
    void testAñadirYBuscarProducto() {
        Inventario inventario = new Inventario();
        Producto producto = new Producto("003", "Bolígrafo", 1.2, 30);

        inventario.añadirProducto(producto);
        Producto encontrado = inventario.buscarProductoPorCodigo("003");

        assertNotNull(encontrado);
        assertEquals("Bolígrafo", encontrado.getNombre());
    }

    @Test
    void testBuscarProductoNoExistente() {
        Inventario inventario = new Inventario();
        Producto producto = inventario.buscarProductoPorCodigo("999");

        assertNull(producto); // Verifica que no se encuentra el producto
    }

    @Test
    void testActualizarStock() {
        Inventario inventario = new Inventario();
        Producto producto = new Producto("004", "Goma", 0.8, 10);

        inventario.añadirProducto(producto);
        inventario.actualizarStock("004", 20);

        assertEquals(20, producto.getStock());
    }

    @Test
    void testEliminarProducto() {
        Inventario inventario = new Inventario();
        Producto producto = new Producto("005", "Regla", 1.5, 15);

        inventario.añadirProducto(producto);
        inventario.eliminarProducto("005");

        assertNull(inventario.buscarProductoPorCodigo("005"));
    }

    @Test
    void testListarProductos() {
        Inventario inventario = new Inventario();
        Producto producto1 = new Producto("006", "Tijeras", 3.0, 5);
        Producto producto2 = new Producto("007", "Pegamento", 1.0, 20);

        inventario.añadirProducto(producto1);
        inventario.añadirProducto(producto2);

        List<Producto> productos = inventario.listarProductos();
        assertEquals(2, productos.size());
    }
}

